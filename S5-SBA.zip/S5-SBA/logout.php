<?php
session_start(); // Start the session
session_destroy(); // Destroy the session to log the user out
header("Location: login.php"); // Redirect to the login page
exit;
?>